# Hisareynspor ücretsiz web sitesi v2

GitHub Pages için hazırdır.

1. GitHub'da `hisareynspor` adlı repository oluşturun.
2. `index.html` ve `logo.png` dosyalarını yükleyin.
3. Settings > Pages > Deploy from a branch > main > / (root) > Save.
4. Site ücretsiz olarak `kullaniciadiniz.github.io/hisareynspor/` adresinde yayınlanır.

Not: Google Haberler'deki sonuçları statik bir GitHub sitesi kendi kendine düzenli olarak çekmez. Bu sürüm güncel haberleri seçilmiş kaynaklardan bağlantılı olarak gösterir ve Google Haberler'e doğrudan arama bağlantısı verir. Otomatik haber akışı istenirse sonraki sürümde RSS/API tabanlı bir sistem kurulabilir.
